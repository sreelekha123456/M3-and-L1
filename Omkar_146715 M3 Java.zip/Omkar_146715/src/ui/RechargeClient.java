package ui;

import java.util.Scanner;


import bean.RechargeDetails;
import exception.RechargeException;
import java.util.ArrayList;
import java.util.Random;
import service.RechargeCollectionHelper;
import service.RechargeDataValidator;



public class RechargeClient
{
	static Scanner sc=new Scanner(System.in);
	static RechargeCollectionHelper rechargecollectionhelper=null;


    //Main method
	public static void main(String[] args)
	{
		int choice;
		rechargecollectionhelper=new RechargeCollectionHelper();
		
		while(true)
		{
			//Providing user interface
			System.out.println("Online DTH Recharge \n***************** \n 1. Make a Recharge\n"
				+ "2. Display Recharge Details" + "\n 3.Exit");		
			System.out.println("\nEnter your choice :");
		choice=sc.nextInt();
		switch(choice)
		{
		
		//Calling makearecharge method for getting & displaying book details 
		case 1:enterRechargeDetails();break;
		//case 2:displayRechargeDetails();break;
		case 3:System.out.println("Exiting...");
		System.exit(0);
		default: System.out.println("Please enter correct choice");
		break;
		
		}
	}
}
	
	    //method for getting & displaying book details
		private static void enterRechargeDetails() 
		{
			System.out.println("select DTH Operator(Airtel/DishTv/Reliance/TATASky:");
			String DTHOperator=sc.next();
			
			try 
			{
				//sending input to validateDTHOperator method for validating consumer No
				if(RechargeDataValidator.validateDTHOperator(DTHOperator))
				{
					System.out.println("Enter Registered Consumer No:");
					int consumerNo=sc.nextInt();
					if(RechargeDataValidator.validateConsumerNO(DTHOperator))
					{
						System.out.println("Enter Recharge Plan:");
						int Plan=sc.nextInt();
				}
			
		}}
			catch (RechargeException e)
		{			
			System.out.println(e.getMessage());
		}		

}}
		
				//sending input to validateConcumerNo method for validating DTHOperator
//			if(RechargeDataValidator.validateConsumerNo(ConsumerNo))
//			{
//					System.out.println("select plan(Monthly/Quarterly/Half yearly/Annual:");
//					String plan=sc.next();
//				
//				if(RechargeDataValidator.validatePlan(rechargePlan))
//			{
//					System.out.println("Enter Amount:");
//					String amount=sc.next();
//				
//				if(RechargeDataValidator.validateAmount(amount))
//				{
//					System.out.println("Enter Amount:");
//					int amount=sc.nextInt();
//				
//			
				
//				if(RechargeDataValidator.validateTransactionID(tranid))
//				{
//											
//					//Generate  Random Reference Id
//					Random ran=new Random();
//					int tranid=ran.nextInt();
//				
//
//					//sending valid input data to the constructor of BookDetails class
//					RechargeDetails cc=new RechargeDetails();
//					//adding valid input data of Recharge details to the array list
//					RechargeCollectionHelper.addRecharge(cc);
//					//displaying all the existing Recharge details of the arrary list
//					RechargeCollectionHelper.displayRechargeDetails();
//				}
//					
//				}
//			
//			
//				

