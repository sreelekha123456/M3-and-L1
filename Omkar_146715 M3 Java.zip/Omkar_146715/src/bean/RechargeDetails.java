/*******Author Name : Omkar  Emp Id : 146715 Date: 04.05.2018 **/
//Purpose: To provide getters and setters for Recharge details

package bean;

public class RechargeDetails 
{
	
	String dthOperator;
	int consumerNo;
	String rechargePlan;
	int amount;
	int transactionID;
	
	//default constructor
	public RechargeDetails()
	{
		
	}
	//initializing instance variables
    public RechargeDetails(String dthOperator,int consumerNo,String rechargePlan,int amount,int transactionID)
    {
    	super();
    	this.dthOperator = dthOperator;
    	this.consumerNo = consumerNo;
    	this.rechargePlan = rechargePlan;
    	this.amount = amount;
    	this.transactionID = transactionID;
	}
   //getter for dthOperator
	public String getDthOperator() 
	{
		return dthOperator;
	}
	//setter for dthOperator
	public void setDthOperator(String dthOperator) 
	{
		this.dthOperator = dthOperator;
	}
	//getter for consumerNo
	public int getConsumerNo() 
	{
		return consumerNo;
	}
	//setter for consumerNo
	public void setConsumerNo(int consumerNo) 
	{
		this.consumerNo = consumerNo;
	}
	//getter for rechargePlan
	public String getRechargePlan()
	{
		return rechargePlan;
	}
	//setter for rechargePlan
	public void setRechargePlan(String rechargePlan) 
	{
		this.rechargePlan = rechargePlan;
	}
	//getter for amount
	public int getAmount()
	{
		return amount;
	}
	//setter for amount
	public void setAmount(int amount) 
	{
		this.amount = amount;
	}
	//getter for transactionID
	public int getTransactionID()
	{
		return transactionID;
	}
	//setter for transactionID
	public void setTransactionID(int transactionID) 
	{
		this.transactionID = transactionID;
	}
	//displaying RechargeDetails
	@Override
	public String toString()
	{
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo=" + consumerNo + ", rechargePlan="
				+ rechargePlan + ", amount=" + amount + ", transactionID=" + transactionID + "]";
	}

}
