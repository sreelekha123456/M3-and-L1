package service;
import java.util.regex.Pattern;
import exception.RechargeException;
public class RechargeDataValidator {

        //validating DTH Operator - it should be Airtel/Dish Tv/Reliance/TATASky
		public  static  boolean validateDTHOperator(String dthType)throws RechargeException
		{
			if(dthType.equalsIgnoreCase("AIRTEL")||(dthType.equalsIgnoreCase("DISHTV"))||(dthType.equalsIgnoreCase("RELIANCE"))||(dthType.equalsIgnoreCase("TATASKY")))
			{
				return true;
			}
			else
			{
				throw new RechargeException("DTH Operator Should Be Either Airtle/DishTv/Reliance/TATASky");
			}
		}
		//validating Recharge Plan - it should be Monthly/Quaterly/Halfyearly/Annual
		public  static  boolean validatePlan(String planType)throws RechargeException
		{
			if(planType.equalsIgnoreCase("Monthly")||(planType.equalsIgnoreCase("Quaterly"))||(planType.equalsIgnoreCase("Halfyearly"))||(planType.equalsIgnoreCase("Annual")))
			{
				return true;
			}
			else
			{
				throw new RechargeException("Recharge Plan Should Be Monthly/Quaterly/HalfYearly/Annual");
			}
		}
		//validating ConsumerNo - it should contain only 10 digit number
				public  static  boolean validateConsumerNO(String consumerno)throws RechargeException
				{
					String consumernoPattern="[0-9]*";
					if(Pattern.matches(consumernoPattern,consumerno))
					{
						return true;
					}
					else
					{
						throw new RechargeException("Consumer No should contain only a 10 digit num");
					}
				}
				//validating Recharge Amount - it should be of number and minium 3, maximum 4
				public  static  boolean validateAmount(String amount)throws RechargeException
				{
					String amountPattern="[0-9]*";
					if(Pattern.matches(amountPattern,amount))
					{
						return true;
					}
					else
					{
						throw new RechargeException("Amount should be a num");
					}
				}
				
		
}