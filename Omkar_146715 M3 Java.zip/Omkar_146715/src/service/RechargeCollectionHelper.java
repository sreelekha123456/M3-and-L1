package service;


import java.util.ArrayList;
import java.util.Iterator;
import bean.RechargeDetails;

public class RechargeCollectionHelper {


private  static ArrayList<RechargeDetails> rechargeList=null;
static
{
	rechargeList=new ArrayList<RechargeDetails>();
	RechargeDetails rechargeDetails1=new RechargeDetails("Airtel",1089343431,"Monthly",210,4567);
	RechargeDetails rechargeDetails2=new RechargeDetails("DishTv",1033221223,"Yearly",1260,4567);
	RechargeDetails rechargeDetails3=new RechargeDetails("Reliance",1923434300,"Quaterly",650,1234);

	rechargeList.add(rechargeDetails1);
   rechargeList.add(rechargeDetails2);
}

public RechargeCollectionHelper(){}

//adding Recharge details to the array list


public static void addRecharge(RechargeDetails rechargeDetails) 
{			
		rechargeList.add(rechargeDetails);				
}

public static ArrayList<RechargeDetails> geBookList() {
	return rechargeList;
}

public static void setRechargeList(ArrayList<RechargeDetails> rechargeList) {
	RechargeCollectionHelper.rechargeList = rechargeList;
}

//displaying all Recharge details
public static  void displayRechargeDetails(int transactionID)
{
	Iterator<RechargeDetails> rechargeIt=rechargeList.iterator();
	RechargeDetails tempRecharge=null;
	while(rechargeIt.hasNext())
	{
		tempRecharge=rechargeIt.next();
		System.out.println(tempRecharge);			
	}
}



}
