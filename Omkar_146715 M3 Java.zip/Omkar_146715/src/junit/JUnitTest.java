package junit;

import static org.junit.Assert.*;

import org.junit.Test;

import bean.RechargeDetails;
import exception.RechargeException;
import junit.framework.Assert;
import service.RechargeCollectionHelper;

public class JUnitTest {

	
		
		static RechargeCollectionHelper RechargeCollectionHelper;
		static RechargeDetails all=null;

		//adding asset details to the array list
		@org.junit.BeforeClass
		public   static  void beforeClass()
		{
			RechargeCollectionHelper=new RechargeCollectionHelper();
			all=new RechargeDetails("TATA Sky", 256896, "Quarterly", 250, 145);	
		}
		
		//clearing the arraylist
		@org.junit.AfterClass
		public static  void afterClass()
		{		
			RechargeCollectionHelper=null;
			all=null;
		}	                                                                                                                                                                                                                        
		
		//checking whether asset details are present in array list
		@Test 
		public void test1() throws RechargeException
		{
			RechargeCollectionHelper.addRecharge(all);
			Assert.assertNotNull(all.getAmount());
		}
		
		@Test 
		public void test2() throws RechargeException
		{
			//RechargeCollectionHelper.addRecharge(all);
			Assert.assertNotNull(all.getAmount());
		}
	}


