package com.cg.technizant;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ApplicantUI {
	static Scanner sc = new Scanner(System.in);
	static CollectionHelper collectionhelper = null;
	private static ArrayList<ApplicantDetails> list = null;

	/*@SuppressWarnings("static-access")*/
	public static void main(String[] args) {
		ApplicantUI ui = new ApplicantUI();
		ui.menu();
	}

	private void menu() {
		int choice = 0;
		collectionhelper = new CollectionHelper();

		while (true) {
			System.out
					.println("\n"
							+ "=============MENU============= \n"
							+ "1: Enter applicant details and Generate Application ID \n"
							+ "2: Delete applicant details based on application id \n"
							+ "0: Exit Menu \n");

			System.out.println("Enter your Choice: ");
			choice = sc.nextInt();
			switch (choice) {
			case 0:
				System.out.println("=============END=============");
				System.exit(0);
			case 1:
				enterApplicantDetails();
				break;
			case 2:
				deleteApplicantDetails();
				break;
			default:
				System.out.println("Invalid Choice!");
				continue;
			}
		}
	}

	private static void enterApplicantDetails() {
		System.out
				.println("Your Application ID will be Auto generated after filling this form!");
		try {
			String appId = collectionhelper.genAppId();
			if (DataValidator.validateAppId(appId)) {
				System.out.print("\nEnter First name :");
				String firstName = sc.next();
				if (DataValidator.validateName(firstName)) {
					System.out.print("\nEnter Last name :");
					String lastName = sc.next();
					if (DataValidator.validateName(lastName)) {
						System.out.print("\nEnter Contact Number : ");
						String contact = sc.next();
						if (DataValidator.validateContact(contact)) {
							System.out.print("\nEnter Email : ");
							String email = sc.next();
							if (DataValidator.validateEmail(email)) {
								System.out.print("\nEnter Course Interested "
										+ "(Java/DotNet/Software Testing) : ");
								String course = sc.next();
								if (DataValidator.validateCourse(course)) {
									ApplicantDetails applicant = new ApplicantDetails(
											Long.parseLong(appId), firstName,
											lastName, contact, email, course);
									collectionhelper
											.addNewApplicant(applicant);
									System.out
											.println("\nYour Application has been"
													+ " successfully submitted your ID is "
													+ appId);
									System.out
											.println("\nYour details are as follows : ");
									collectionhelper.displayDetails(appId);
								}
							}
						}
					}
				}
			}
		} catch (ExceptionHandler e) {
			System.out.println(e.getMessage());
		}
	}

	private static void deleteApplicantDetails() {
		Iterator<ApplicantDetails> It = list.iterator();
		ApplicantDetails temp = null;
		System.out.println("Enter Applicant Id :");
		String appId = sc.next();

		try {
			if (DataValidator.validateAppId(appId)) {
				while (It.hasNext()) {
					temp = It.next();
					if ((temp.getApplicantId()) == Long.parseLong(appId)) {
						ApplicantDetails applicant = new ApplicantDetails(temp.getApplicantId(),
								temp.getFirstName(),temp.getLastName(),temp.getApplicantMobile(),
								temp.getApplicantEmail(),temp.getInterestedCourse());
						collectionhelper.deleteApplicant(applicant);
					}
				
				}
			} 
		} catch (ExceptionHandler e) {
			System.out.println(e.getMessage());
		}

	}
}