package com.cg.technizant;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionHelper {
	private static ArrayList<ApplicantDetails> list = null;
	static {
		list = new ArrayList<ApplicantDetails>();
		ApplicantDetails a1 = new ApplicantDetails(9998,"Bill","Gates","bill.gates@gmail.com","9876543210","Java");
		ApplicantDetails a2 = new ApplicantDetails(9999,"Saurav","Santara","saurav.santara@gmail.com",
				"8765432109","Software Testing");

		list.add(a1);
		list.add(a2);

	}

	public CollectionHelper() {
	}

	/*************Generate Application ID ************/
	public String genAppId() {
		long num = 0;
		String appId;
		Iterator<ApplicantDetails> It = list.iterator();
		ApplicantDetails temp = null;

		while (It.hasNext()) {
			temp = It.next();
			num = temp.getApplicantId();
			num = num + 1;
			if(num != temp.getApplicantId()) {
				break;
			}
		}	
		appId = Long.toString(num);
		return appId;
	}
	
	/************* Add ApplicantDetails in ArrayList ************/
	public void addNewApplicant(ApplicantDetails applicant) {
		list.add(applicant);
	}

	public static ArrayList<ApplicantDetails> getList() {
		return list;
	}

	public static void setList(ArrayList<ApplicantDetails> list) {
		CollectionHelper.list = list;
	}

	/************* Fetch a Particular Applicant's Detail ***********/
	public void displayDetails(String appId) {

		Iterator<ApplicantDetails> It = list.iterator();
		ApplicantDetails temp = null;
		boolean flag = false;

		while (It.hasNext()) {
			temp = It.next();
			if ((temp.getApplicantId()) == Long.parseLong(appId)) {
				System.out.println(temp);
				flag = true;
			}
		}
		if (flag == false) {
			System.out.println("ERROR! Unable to display applicant details.");
		}
	}

	/************* Delete a Particular Applicant's Detail ***********/
	public void deleteApplicant(ApplicantDetails applicant) {

		Iterator<ApplicantDetails> It = list.iterator();
		ApplicantDetails temp = null;
		boolean flag = false;

		while (It.hasNext()) {
			temp = It.next();
			if (temp == applicant) {
				flag = true;
				temp.setApplicantId(1000);
				temp.setFirstName(null);
				temp.setLastName(null);
				temp.setApplicantMobile(null);
				temp.setApplicantEmail(null);
				temp.setInterestedCourse(null);
				System.out.println("Application details deleted successfully.");
			}
		}
		if (flag == false) {
			System.out.println("Application ID does not exist.");
		}
	}
}
