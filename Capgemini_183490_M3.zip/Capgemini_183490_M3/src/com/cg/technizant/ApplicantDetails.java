package com.cg.technizant;

public class ApplicantDetails {

	private long applicantId = 1000;
	private String firstName;
	private String lastName;
	private String applicantEmail;
	private String applicantMobile;
	private String interestedCourse;
	
	public ApplicantDetails() {
		super();
	}

	public ApplicantDetails(long applicantId, String firstName,
			String lastName, String applicantEmail, String applicantMobile,
			String interestedCourse) {
		super();
		this.applicantId = applicantId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.applicantEmail = applicantEmail;
		this.applicantMobile = applicantMobile;
		this.interestedCourse = interestedCourse;
	}

	public long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(long applicantId) {
		this.applicantId = applicantId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getApplicantEmail() {
		return applicantEmail;
	}

	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}

	public String getApplicantMobile() {
		return applicantMobile;
	}

	public void setApplicantMobile(String applicantMobile) {
		this.applicantMobile = applicantMobile;
	}

	public String getInterestedCourse() {
		return interestedCourse;
	}

	public void setInterestedCourse(String interestedCourse) {
		this.interestedCourse = interestedCourse;
	}

	@Override
	public String toString() {
		return "ApplicantDetails [applicantId=" + applicantId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", applicantEmail="
				+ applicantEmail + ", applicantMobile=" + applicantMobile
				+ ", interestedCourse=" + interestedCourse + "]";
	}

	
}
