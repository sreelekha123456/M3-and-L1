package com.cg.technizant;

import java.util.regex.Pattern;

public class DataValidator {
	
	public static boolean validateAppId(String appId) throws ExceptionHandler {
		String numPattern = "[1-9]{1}\\d{3}";
		if (Pattern.matches(numPattern, appId)) {
			return true;
		} else {
			throw new ExceptionHandler(
					"ERROR! Unable to generate Applicant ID.");
		}
	}

	public static boolean validateName(String name) throws ExceptionHandler {
		String namePattern = "[A-Za-z\\s]{3,20}";
		if (Pattern.matches(namePattern, name)) {
			return true;
		} else {
			throw new ExceptionHandler(
					"Name should start with CAPITAL & Min 3 and Max 20 characters Allowed.");
		}

	}

	public static boolean validateContact(String contact) throws ExceptionHandler {
		String contactPattern = "[1-9]{1}\\d{9}";		 
		if (Pattern.matches(contactPattern, contact)) {
			return true;
		} else {
			throw new ExceptionHandler("1. Contact number should be of 10 digits only. \n"
					+ "2. Contact number cannot start with zero.");
		}
		
	}

	public static boolean validateEmail(String email) throws ExceptionHandler {	
		String emailPattern = "^[\\w.]+@[A-Za-z]+\\.[A-Za-z]{2,6}+";
		if (Pattern.matches(emailPattern, email)) {
			return true;
		} else {
			throw new ExceptionHandler("Email should be in format \"someone@domainname.com\" only.");
		}

	}
	
	public static boolean validateCourse(String course) throws ExceptionHandler {	
		String coursePattern = "Java|DotNet|Software Testing";
		if (Pattern.matches(coursePattern, course)) {
			return true;
		} else {
			throw new ExceptionHandler("Course can only be one of the three \n"
					+ "1. Java \n2. DotNet \n3. Software Testing \n"
					+ "The options are case sensitive.");
		}

	}
}
