/**
 * 
 */
package com.cg.technizant;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author sasantar
 *
 */
public class DataValidatorTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
