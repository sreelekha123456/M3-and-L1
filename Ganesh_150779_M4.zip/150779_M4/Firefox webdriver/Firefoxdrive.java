import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Firefoxdrive {

		public static void main(String[] args) throws InterruptedException 
		{
			System.setProperty("webdriver.firefox.bin",
					"C:/Users/kosvenka/AppData/Local/Mozilla Firefox/firefox.exe");
	        FirefoxProfile profile = new FirefoxProfile();
	        profile.setPreference("network.proxy.type", 1);//Configuring the firefox browser
	        profile.setPreference("network.proxy.http", "10.219.96.26");
	        profile.setPreference("network.proxy.http_port", 8080);
	        profile.setPreference("network.proxy.ssl", "10.219.96.26");
	        profile.setPreference("network.proxy.ssl_port", 8080);
	        
	        FirefoxDriver driver = new FirefoxDriver(profile);
	        driver.get("http://demo.opencart.com");//Opening the file in firefox
			Thread.sleep(1000);
			System.out.println("Webpage openend");
			//Maximizes the browser window
			driver.manage().window().maximize() ;
			
			Thread.sleep(1500);
	        System.out.println("execution is paused for 1.5 seconds");
	        String title1 = "Your Store";
	        boolean source = driver.getPageSource().contains(title1);
	        
	        if(source)
	        {
	        	System.out.println("Title is verified");//Verifying the title
	        }
	        else
	        {
	        	System.out.println(title1 + " is not present");
	        }
	        System.out.println("Waiting for the page to load");
	        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;//Stopping the execution until the browser loads 
	        java.util.List<WebElement> links = driver.findElements(By.tagName("a"));
	        
			int link=links.size();//Finding the number of links in the home page.
			if(link==73)
					{
						System.out.println("Links verified");
					}
			driver.findElement(By.className("caret")).click();
			Thread.sleep(1000);
			System.out.println("Clicked on Account");
			driver.findElement(By.cssSelector(".dropdown-menu.dropdown-menu-right>li>a")).click();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
			System.out.println("Clicked on Register");
			driver.findElement(By.xpath(".//*[@id='input-firstname']")).sendKeys("Ganesh");//User name field is filled
			WebElement we = driver.findElement(By.xpath(".//*[@id='input-firstname']"));
			String name = we.getAttribute("value");
			if(DataValidator.ValidUsername(name))//Validating first name
			{
				System.out.println("First name verified");
				driver.findElement(By.name("lastname")).sendKeys("Kosuri");//Entering the values for last name field
				Thread.sleep(1000);
				WebElement last = driver.findElement(By.name("lastname"));
				String lname = last.getAttribute("value");
				if(DataValidator.ValidUsername(lname))//Validating last name
				{
					System.out.println("Last name verified");			
					driver.findElement(By.cssSelector("#input-email")).sendKeys("ganeshkosuri@gmail.com");//Enter a new email for every iteration
					Thread.sleep(1000);
					WebElement mail = driver.findElement(By.cssSelector("#input-email"));
					String vmail = mail.getAttribute("value");
					if(DataValidator.Validatemail(vmail))//Validating email
					{
						System.out.println("Email is verified");
						
							driver.findElement(By.cssSelector("#input-password")).sendKeys("Kramadevi@457");
							Thread.sleep(1000);
							WebElement pwrd = driver.findElement(By.className("form-control"));
							String password = pwrd.getAttribute("value");
							driver.findElement(By.id("input-confirm")).sendKeys("Kramadevi@457");
							WebElement pwrd1 = driver.findElement(By.className("form-control"));
							String password1 = pwrd1.getAttribute("value");
							if(password.equals(password1))
							{
								System.out.println("Entered Passwords are matching");
							}
							driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[2]/input")).click();
							driver.findElement(By.name("agree")).click();
							driver.findElement(By.cssSelector(".btn.btn-primary")).click();
							boolean msg=driver.getPageSource().contains("Telephone must be between 3 and 32 characters!");
					        if(msg){
					        	System.out.println("Telephone numnber error message is verified"); 
					        }
					        else{
					        	System.out.println("Telephone number error message is not verified");
					        	
					        }
						}
						
					}
					
				}
			
		driver.findElement(By.id("input-telephone")).sendKeys("9398402005");
		Thread.sleep(1000);
		WebElement phone = driver.findElement(By.id("input-telephone"));
		String number = phone.getAttribute("value");
		if(DataValidator.ValidateNumber(number))
		{
			System.out.println("Phone number verified");
			System.out.println("Telephone number is valid");
			
	        driver.findElement(By.cssSelector(".btn.btn-primary")).click();
	        Thread.sleep(1500);// waiting for the page to load
	        boolean p=driver.getPageSource().contains("Your Account Has Been Created!");
	        if(p){
	        	System.out.println("Title has been verified"); 
	        }
	        else{
	        	System.out.println("Title verification is failed");
	        	
	        }
	        driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[6]/a")).click();
	        Thread.sleep(1500);
	        driver.findElement(By.linkText("HTC Touch HD")).click();
	        boolean text5=driver.getPageSource().contains("HTC Touch HD");
	    	if(text5)
	    	{
	    		System.out.println("HTC Touch HD is present");
	    	}
	    	else
	    	{
	    		System.out.println("HTC Touch HD is not present");
	    	}
	    	Thread.sleep(1500);
	    	driver.navigate().back();
	    	
	    	driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/button[1]")).click();
	    	System.out.println("Add to cart button is clicked");
	    	
	    	Thread.sleep(1500);
	    	boolean text6=driver.getPageSource().contains("Success: You have added HTC Touch HD to your shopping cart!");
	    	if(text6)
	    	{
	    		System.out.println("Success: You have added HTC Touch HD to your shopping cart! is present");
	    	}
	    	else
	    	{
	    		System.out.println("Success: You have added HTC Touch HD to your shopping cart! is not present");
	    	}
	    	Thread.sleep(1500);
	    	driver.findElement(By.linkText("Brands")).click();
	    	
	    	boolean title11=driver.getTitle().contains("Find Your Favorite Brand");
	    	if(title11)
	    	{
	    		System.out.println("Title matches");
	    	}
	    	else
	    	{
	    		System.out.println("Title not matches");
	    	}
	    	driver.findElement(By.linkText("Canon")).click();
	    	boolean text7=driver.getPageSource().contains("Canon");
	    	if(text7)
	    	{
	    		System.out.println("Canon is present");
	    	}
	    	else
	    	{
	    		System.out.println("Canon is not present");
	    	}
	    	
	    	driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/button[2]")).click();
	    	System.out.println("Clicked on add to wishlist icon");
	    	
	    	Thread.sleep(1000);
	    	boolean text8=driver.getPageSource().contains("Success: You have added Canon EOS 5D to your wish list!");
	    	if(text8)
	    	{
	    		System.out.println("Success: You have added Canon EOS 5D to your wish list! is present");
	    	}
	    	else
	    	{
	    		System.out.println("Success: You have added Canon EOS 5D to your wish list! is not present");
	    	}
	    	
	    	driver.findElement(By.linkText("Wish List (1)")).click();
	    	
	    	boolean title2=driver.getTitle().contains("My Wish List");
	    	if(title2)
	    	{
	    		System.out.println("Title matches");
	    	}
	    	else
	    	{
	    		System.out.println("Title not matches");
	    	}
	    	
	    	Thread.sleep(1500);
	    	driver.close();

		    }
		}
		

}
